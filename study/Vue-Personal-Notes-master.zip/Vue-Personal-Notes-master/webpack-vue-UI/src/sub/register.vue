<template>
    <div>
        <h1>这是 注册 组件</h1>
    </div>
</template>

<script>
    
</script>

<style lang="">
    
</style>