<template>
    <div>
        <h1>这是Goodslist组件</h1>
    </div>
</template>

<script>
    
</script>

<style lang="">
    
</style>