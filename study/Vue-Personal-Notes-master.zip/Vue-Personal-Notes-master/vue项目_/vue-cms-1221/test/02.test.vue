<template>
  <div>
    <h3>哈哈哈哈哈哈哈哈</h3>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>
<style lang="scss" scoped>
h3 {
  color: pink;
}
</style>

