<template>
  <div>
    <h3>SearchContainer</h3>
    <mytest></mytest>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="scss" scoped>

</style>
